<?php
defined('BASEPATH') or exit('No direct script access allowed');

class MenuConf_model extends CI_Model
{

  // ------------------------------------------------------------------------

  public function __construct()
  {
    parent::__construct();
  }

  // ------------------------------------------------------------------------


  // ------------------------------------------------------------------------
  public function index()
  {
    // 
  }

  // ------------------------------------------------------------------------

}

/* End of file MenuConf_model.php */
/* Location: ./application/models/MenuConf_model.php */