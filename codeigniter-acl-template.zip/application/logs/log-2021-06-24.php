<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
ERROR - 2021-06-24 14:24:56 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:28:38 --> 404 Page Not Found: User/imagesERROR - 2021-06-24 14:33:15 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:33:57 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:34:01 --> Could not find the language line "form_validation_email"
ERROR - 2021-06-24 14:34:53 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:35:14 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:36:07 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:37:13 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:40:39 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:40:51 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:43:45 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:43:55 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:44:24 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:50:28 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:50:36 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:51:14 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:51:50 --> 404 Page Not Found: User/index3.html
ERROR - 2021-06-24 14:51:55 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 14:52:01 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:52:05 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:52:37 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:52:56 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:53:23 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:53:26 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:57:33 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:57:54 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:58:04 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:58:10 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 14:59:49 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:02:31 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:02:54 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:03:25 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:03:38 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:04:15 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:04:58 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:05:34 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:05:45 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:06:16 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:06:29 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:06:36 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:06:44 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:06:56 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:07:03 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:07:11 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:08:23 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:09:24 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:10:04 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:10:46 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:14:24 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 15:14:25 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 15:14:26 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:21:47 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:25:19 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:27:22 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:27:42 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 15:30:01 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 15:37:33 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 15:38:00 --> Severity: Notice --> Trying to get property 'count' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 36
ERROR - 2021-06-24 15:38:19 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 36
ERROR - 2021-06-24 15:38:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 36
ERROR - 2021-06-24 15:39:17 --> Severity: Notice --> Trying to get property 'count' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 37
ERROR - 2021-06-24 15:39:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 37
ERROR - 2021-06-24 15:52:26 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 15:55:56 --> Severity: error --> Exception: Call to undefined method CI_Session::flash_data() D:\xampp\htdocs\kumpul\codeigniter-acl\application\views\backend\users\index.php 55
ERROR - 2021-06-24 15:56:16 --> Severity: error --> Exception: Call to undefined method CI_Session::flash_data() D:\xampp\htdocs\kumpul\codeigniter-acl\application\views\backend\users\index.php 55
ERROR - 2021-06-24 15:56:16 --> Severity: error --> Exception: Call to undefined method CI_Session::flash_data() D:\xampp\htdocs\kumpul\codeigniter-acl\application\views\backend\users\index.php 55
ERROR - 2021-06-24 15:56:17 --> Severity: error --> Exception: Call to undefined method CI_Session::flash_data() D:\xampp\htdocs\kumpul\codeigniter-acl\application\views\backend\users\index.php 55
ERROR - 2021-06-24 15:56:17 --> Severity: error --> Exception: Call to undefined method CI_Session::flash_data() D:\xampp\htdocs\kumpul\codeigniter-acl\application\views\backend\users\index.php 55
ERROR - 2021-06-24 15:56:17 --> Severity: error --> Exception: Call to undefined method CI_Session::flash_data() D:\xampp\htdocs\kumpul\codeigniter-acl\application\views\backend\users\index.php 55
ERROR - 2021-06-24 15:56:31 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 15:56:36 --> Severity: error --> Exception: Call to undefined method CI_Session::flash_data() D:\xampp\htdocs\kumpul\codeigniter-acl\application\views\backend\users\index.php 55
ERROR - 2021-06-24 15:58:21 --> Severity: error --> Exception: Call to undefined method CI_Session::flash_data() D:\xampp\htdocs\kumpul\codeigniter-acl\application\views\backend\users\index.php 17
ERROR - 2021-06-24 15:58:37 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:04:01 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:04:01 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:04:46 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:05:05 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:05:16 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:05:27 --> 404 Page Not Found: Users/index
ERROR - 2021-06-24 16:05:52 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:06:01 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:06:41 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:08:06 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:08:17 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:08:24 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:08:26 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:08:26 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:08:44 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:08:45 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:09:12 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:09:12 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:09:27 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:09:27 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:09:32 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:09:46 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:09:57 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:09:59 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:10:12 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:10:15 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:10:15 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:10:31 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:10:31 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:10:42 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:10:42 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:11:48 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:11:48 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:12:45 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:12:45 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:14:46 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:14:46 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:14:47 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:14:47 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:14:50 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:14:50 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:15:01 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:15:02 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:15:06 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:15:06 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:15:26 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:15:26 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:19:27 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:19:27 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:22:22 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:22:38 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:22:42 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:22:42 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:23:16 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:23:16 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:23:18 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:23:18 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:23:31 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:23:31 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:44:50 --> Severity: Notice --> Undefined property: UsersController::$encrypt D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 29
ERROR - 2021-06-24 16:44:50 --> Severity: error --> Exception: Call to a member function encode() on null D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 29
ERROR - 2021-06-24 16:45:20 --> Severity: Notice --> Undefined property: UsersController::$encrypt D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 29
ERROR - 2021-06-24 16:45:20 --> Severity: error --> Exception: Call to a member function encode() on null D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 29
ERROR - 2021-06-24 16:45:21 --> Severity: Notice --> Undefined property: UsersController::$encrypt D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 29
ERROR - 2021-06-24 16:45:21 --> Severity: error --> Exception: Call to a member function encode() on null D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 29
ERROR - 2021-06-24 16:45:21 --> Severity: Notice --> Undefined property: UsersController::$encrypt D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 29
ERROR - 2021-06-24 16:45:21 --> Severity: error --> Exception: Call to a member function encode() on null D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 29
ERROR - 2021-06-24 16:45:21 --> Severity: Notice --> Undefined property: UsersController::$encrypt D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 29
ERROR - 2021-06-24 16:45:21 --> Severity: error --> Exception: Call to a member function encode() on null D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 29
ERROR - 2021-06-24 16:45:21 --> Severity: Notice --> Undefined property: UsersController::$encrypt D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 29
ERROR - 2021-06-24 16:45:21 --> Severity: error --> Exception: Call to a member function encode() on null D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 29
ERROR - 2021-06-24 16:46:29 --> Severity: error --> Exception: Call to undefined method CI_Encryption::encode() D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 29
ERROR - 2021-06-24 16:49:12 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:49:14 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:49:14 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:53:14 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:53:14 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:53:42 --> Severity: Notice --> Trying to get property 'username' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 34
ERROR - 2021-06-24 16:53:42 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 35
ERROR - 2021-06-24 16:53:42 --> Severity: Notice --> Trying to get property 'email' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 36
ERROR - 2021-06-24 16:53:42 --> Severity: Notice --> Trying to get property 'img' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 37
ERROR - 2021-06-24 16:53:42 --> Severity: Notice --> Trying to get property 'password' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 38
ERROR - 2021-06-24 16:53:42 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `users` (`username`, `nama`, `email`, `img`, `password`) VALUES (NULL, NULL, NULL, NULL, '3a8655d23f1568b1ebc791a1066741acc129290f33f99a9eb19ebf59d06f64a7fc308e857ce14a90c1d3be42f89050d1e0426f3b3e0b5ecb3755d7fb8eab4b270ne/t1+kZ2m+FdUAwXzWpxh4MHU0DRwhzIRRQWIooMQ=')
ERROR - 2021-06-24 16:53:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\kumpul\codeigniter-acl\system\core\Exceptions.php:271) D:\xampp\htdocs\kumpul\codeigniter-acl\system\core\Common.php 570
ERROR - 2021-06-24 16:54:36 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:54:45 --> Severity: Notice --> Trying to get property 'username' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 34
ERROR - 2021-06-24 16:54:45 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 35
ERROR - 2021-06-24 16:54:45 --> Severity: Notice --> Trying to get property 'email' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 36
ERROR - 2021-06-24 16:54:45 --> Severity: Notice --> Trying to get property 'img' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 37
ERROR - 2021-06-24 16:54:45 --> Severity: Notice --> Trying to get property 'password' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 38
ERROR - 2021-06-24 16:55:49 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:55:49 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:56:04 --> Severity: Notice --> Trying to get property 'username' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 34
ERROR - 2021-06-24 16:56:04 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 35
ERROR - 2021-06-24 16:56:04 --> Severity: Notice --> Trying to get property 'email' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 36
ERROR - 2021-06-24 16:56:04 --> Severity: Notice --> Trying to get property 'img' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 37
ERROR - 2021-06-24 16:56:04 --> Severity: Notice --> Trying to get property 'password' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 38
ERROR - 2021-06-24 16:56:04 --> Severity: Notice --> Trying to get property 'username' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 40
ERROR - 2021-06-24 16:56:22 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:56:22 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:56:40 --> Severity: Notice --> Trying to get property 'username' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 34
ERROR - 2021-06-24 16:56:40 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 35
ERROR - 2021-06-24 16:56:40 --> Severity: Notice --> Trying to get property 'email' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 36
ERROR - 2021-06-24 16:56:40 --> Severity: Notice --> Trying to get property 'img' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 37
ERROR - 2021-06-24 16:56:40 --> Severity: Notice --> Trying to get property 'password' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 38
ERROR - 2021-06-24 16:58:36 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:58:38 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:58:39 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:58:39 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:58:40 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:58:40 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:58:52 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:58:52 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:59:03 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:59:03 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:59:05 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:59:05 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:59:07 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:59:21 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:59:21 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 16:59:23 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 16:59:37 --> Severity: error --> Exception: Cannot use object of type Users_model as array D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 38
ERROR - 2021-06-24 17:00:37 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:00:38 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:00:38 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:00:38 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:00:39 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:00:39 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:00:39 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:00:40 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:00:44 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 17:01:28 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:01:28 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:03:13 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:03:13 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:03:23 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:03:23 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:03:27 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:03:32 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:03:35 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 17:03:36 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:03:36 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:03:53 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:03:53 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:04:04 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:04:04 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:04:27 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 17:04:29 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:06:05 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 17:06:06 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:06:08 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 17:06:08 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 17:06:10 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:06:10 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:16:50 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:16:50 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:16:52 --> 404 Page Not Found: User/develop
ERROR - 2021-06-24 17:17:18 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:17:18 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:17:22 --> Severity: error --> Exception: Too few arguments to function UsersController::develop(), 0 passed in D:\xampp\htdocs\kumpul\codeigniter-acl\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\xampp\htdocs\kumpul\codeigniter-acl\application\controllers\UsersController.php 61
ERROR - 2021-06-24 17:17:45 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:17:45 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:17:47 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:17:47 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:18:06 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:18:06 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:18:08 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:18:09 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:18:16 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 17:18:16 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 17:18:40 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:18:40 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:21:47 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 17:21:47 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 17:21:49 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:21:49 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:25:03 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 17:25:41 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:19:24 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:19:25 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2021-06-24 22:19:32 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 22:19:32 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 22:19:32 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 22:19:33 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:19:33 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:21:10 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:21:10 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:21:40 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:22:25 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:22:31 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:22:32 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:22:32 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:22:36 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:22:36 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:22:43 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:22:43 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:22:51 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:22:51 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:23:07 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:23:07 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:23:54 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:23:54 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:24:17 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:24:17 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:24:38 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:24:38 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:24:42 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:24:42 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:28:32 --> 404 Page Not Found: User/images
ERROR - 2021-06-24 22:28:38 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:28:38 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:30:28 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:30:57 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:43:20 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:44:31 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:44:31 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:44:34 --> 404 Page Not Found: User/detail1
ERROR - 2021-06-24 22:45:01 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:45:01 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:45:56 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:45:56 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:47:29 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:47:29 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:47:54 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:47:54 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:48:04 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:48:04 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:48:26 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:48:26 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:48:39 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:48:40 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:56:35 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:56:35 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:57:24 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 22:57:25 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::row() D:\xampp\htdocs\kumpul\codeigniter-acl\application\models\Users_model.php 51
ERROR - 2021-06-24 22:58:02 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 23:01:56 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 23:01:57 --> Severity: Notice --> Undefined property: stdClass::$role_id D:\xampp\htdocs\kumpul\codeigniter-acl\application\views\backend\users\show.php 24
ERROR - 2021-06-24 23:03:16 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 23:05:51 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 23:06:15 --> 404 Page Not Found: Images/img.jpg
ERROR - 2021-06-24 23:06:25 --> 404 Page Not Found: Images/img.jpg
