<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-03 11:08:53 --> 404 Page Not Found: Acl/index
ERROR - 2021-07-03 11:11:32 --> Severity: error --> Exception: syntax error, unexpected '*', expecting end of file D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Acl_model.php 5
ERROR - 2021-07-03 20:11:23 --> Severity: Notice --> Undefined variable: kode_menu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\index.php 22
ERROR - 2021-07-03 20:11:23 --> Severity: Notice --> Undefined variable: submenu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\index.php 37
ERROR - 2021-07-03 20:11:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\index.php 37
ERROR - 2021-07-03 20:11:34 --> Severity: Notice --> Undefined variable: kode_menu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\index.php 22
ERROR - 2021-07-03 20:11:34 --> Severity: Notice --> Undefined variable: submenu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\index.php 37
ERROR - 2021-07-03 20:11:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\index.php 37
ERROR - 2021-07-03 20:11:40 --> Severity: Notice --> Undefined variable: kode_menu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\index.php 22
ERROR - 2021-07-03 20:11:40 --> Severity: Notice --> Undefined variable: submenu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\index.php 37
ERROR - 2021-07-03 20:11:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\index.php 37
ERROR - 2021-07-03 20:11:55 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:11:55 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:14:05 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:14:05 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:21:36 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:21:36 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:21:43 --> 404 Page Not Found: App-/index
ERROR - 2021-07-03 20:21:45 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:21:45 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:21:47 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:21:47 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:26:52 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:26:52 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:28:29 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:28:29 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:28:31 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:28:31 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:31:55 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:31:55 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:53:57 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:53:57 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:54:17 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:54:17 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:57:05 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:57:05 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:57:07 --> 404 Page Not Found: Acl/show
ERROR - 2021-07-03 20:57:40 --> 404 Page Not Found: Acl/show
ERROR - 2021-07-03 20:57:44 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 20:57:44 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:04:35 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:04:35 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:04:36 --> Severity: error --> Exception: Call to undefined method Acl_model::show() D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\AclController.php 40
ERROR - 2021-07-03 21:04:51 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:04:51 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:10:45 --> 404 Page Not Found: Acl/create
ERROR - 2021-07-03 21:10:58 --> 404 Page Not Found: Acl/store
ERROR - 2021-07-03 21:30:04 --> Could not find the language line "insert_batch() called with no data"
ERROR - 2021-07-03 21:30:59 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:30:59 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:31:16 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:31:16 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:31:19 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:31:19 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:31:23 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:31:23 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:36:05 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:36:05 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:36:06 --> Query error: Unknown column 'c.menu' in 'field list' - Invalid query: SELECT `b`.`nama`, `c`.`menu`, `a`.`akses`, `a`.`add`, `a`.`edit`, `a`.`detail`, `a`.`delete`
FROM `acl` `a`
JOIN `users` `b` ON `b`.`id` = `a`.`id_user`
JOIN `menu` `c` ON `c`.`id` = `a`.`id_menu`
WHERE `a`.`id_user` = ''
ERROR - 2021-07-03 21:36:22 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:36:22 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:36:50 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:36:50 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:40:08 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:40:08 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:41:22 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:41:22 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:49:56 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\show.php 6
ERROR - 2021-07-03 21:49:56 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\show.php 10
ERROR - 2021-07-03 21:50:03 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:50:03 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:50:04 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\show.php 6
ERROR - 2021-07-03 21:50:04 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\show.php 10
ERROR - 2021-07-03 21:51:05 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:51:05 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:51:46 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:51:46 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:53:25 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:53:25 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:53:52 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 21:53:52 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:10:54 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:10:54 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:12:11 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:12:11 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:12:18 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:12:18 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:12:45 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:12:45 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:14:57 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:14:57 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:14:58 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:14:58 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:15:14 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:15:14 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:15:58 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:15:58 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:15:59 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:15:59 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:16:15 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:16:15 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:16:15 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:16:15 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:17:19 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:17:19 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:45:37 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:45:37 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:46:00 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:46:00 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:48:05 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:48:05 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:48:23 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:48:23 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:48:36 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:48:36 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:48:50 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:48:50 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:50:18 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:50:18 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:51:59 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:51:59 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:52:10 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:52:10 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:52:19 --> 404 Page Not Found: Public/template
ERROR - 2021-07-03 22:52:19 --> 404 Page Not Found: Public/template
