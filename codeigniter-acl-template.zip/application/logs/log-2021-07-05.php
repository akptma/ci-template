<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-05 09:23:23 --> 404 Page Not Found: Public/template
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-05 09:23:23 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:26:03 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:26:03 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:26:31 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:26:31 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:26:38 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:26:38 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:27:00 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:27:00 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:30:56 --> Severity: Notice --> Undefined variable: sm D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-menu\index.php 30
ERROR - 2021-07-05 09:30:56 --> Severity: Notice --> Trying to get property 'urutan' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-menu\index.php 30
ERROR - 2021-07-05 09:30:56 --> Severity: Notice --> Undefined variable: sm D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-menu\index.php 30
ERROR - 2021-07-05 09:30:56 --> Severity: Notice --> Trying to get property 'urutan' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-menu\index.php 30
ERROR - 2021-07-05 09:30:56 --> Severity: Notice --> Undefined variable: sm D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-menu\index.php 30
ERROR - 2021-07-05 09:30:56 --> Severity: Notice --> Trying to get property 'urutan' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-menu\index.php 30
ERROR - 2021-07-05 09:30:57 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:30:57 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:31:08 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:31:08 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:33:12 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:33:12 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:33:53 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:33:53 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:34:12 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:34:12 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:34:29 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:34:29 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:35:27 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:35:27 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:35:58 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:35:58 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:36:26 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:36:26 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:36:55 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:36:55 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:37:08 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:37:08 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:37:28 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:37:28 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:38:57 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:38:57 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:40:01 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:40:01 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:40:13 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:40:13 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:40:31 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:40:31 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:42:29 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:42:29 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:42:47 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:42:47 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:42:51 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:42:51 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:43:06 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:43:06 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:43:11 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:43:11 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:43:28 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:43:28 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:43:45 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:43:45 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:44:11 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:44:11 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:44:31 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:44:31 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:44:41 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:44:41 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:44:48 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:44:48 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:44:53 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:44:53 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:47:06 --> Severity: Notice --> Undefined property: stdClass::$id_menu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-menu\index.php 39
ERROR - 2021-07-05 09:47:06 --> Severity: Notice --> Undefined property: stdClass::$id_menu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-menu\index.php 39
ERROR - 2021-07-05 09:47:06 --> Severity: Notice --> Undefined property: stdClass::$id_menu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-menu\index.php 39
ERROR - 2021-07-05 09:47:06 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:47:06 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:47:17 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:47:17 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:48:46 --> Severity: Notice --> Undefined variable: id_menu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-menu\index.php 40
ERROR - 2021-07-05 09:48:46 --> Severity: Notice --> Undefined variable: id_menu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-menu\index.php 40
ERROR - 2021-07-05 09:48:46 --> Severity: Notice --> Undefined variable: id_menu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-menu\index.php 40
ERROR - 2021-07-05 09:48:46 --> Severity: Notice --> Undefined variable: id_menu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-menu\index.php 40
ERROR - 2021-07-05 09:48:46 --> Severity: Notice --> Undefined variable: id_menu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-menu\index.php 40
ERROR - 2021-07-05 09:48:46 --> Severity: Notice --> Undefined variable: id_menu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-menu\index.php 40
ERROR - 2021-07-05 09:48:46 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:48:46 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:49:07 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:49:07 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:49:22 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:49:22 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:49:46 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:49:46 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:50:14 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:50:14 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:50:27 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:50:27 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:50:49 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:50:49 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:51:35 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:51:35 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:52:08 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:52:08 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:52:17 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:52:17 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:52:31 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:52:31 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:52:53 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:52:53 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:53:59 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:53:59 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:55:31 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:55:31 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:56:06 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:56:06 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:57:36 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:57:36 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:57:42 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 09:57:42 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:00:50 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:00:50 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:01:14 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:01:14 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:01:42 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:01:42 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:01:55 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:01:55 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:02:06 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:02:06 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:02:18 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:02:18 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:02:19 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:02:19 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:02:22 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:02:22 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:02:26 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:02:26 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:02:43 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:02:43 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:02:52 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:02:52 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:02:56 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:02:56 --> 404 Page Not Found: Public/template
ERROR - 2021-07-05 10:48:41 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\show.php 7
ERROR - 2021-07-05 10:48:41 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\show.php 11
ERROR - 2021-07-05 10:48:41 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\show.php 18
ERROR - 2021-07-05 11:03:50 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 32
ERROR - 2021-07-05 11:03:50 --> Severity: Notice --> Trying to get property 'add' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 21
ERROR - 2021-07-05 11:03:50 --> Severity: Notice --> Trying to get property 'akses' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 27
ERROR - 2021-07-05 11:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\MenuConfController.php 30
ERROR - 2021-07-05 11:04:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\AclController.php 31
ERROR - 2021-07-05 11:04:15 --> Severity: Notice --> Trying to get property 'add' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\index.php 22
ERROR - 2021-07-05 11:04:15 --> Severity: Notice --> Trying to get property 'akses' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\index.php 28
ERROR - 2021-07-05 11:05:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\MenuConfController.php 30
ERROR - 2021-07-05 11:05:18 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 32
ERROR - 2021-07-05 11:05:18 --> Severity: Notice --> Trying to get property 'add' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 21
ERROR - 2021-07-05 11:05:18 --> Severity: Notice --> Trying to get property 'akses' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 27
ERROR - 2021-07-05 11:05:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 32
ERROR - 2021-07-05 11:05:27 --> Severity: Notice --> Trying to get property 'add' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 21
ERROR - 2021-07-05 11:05:27 --> Severity: Notice --> Trying to get property 'akses' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 27
ERROR - 2021-07-05 11:05:57 --> 404 Page Not Found: AclController/create
ERROR - 2021-07-05 11:06:33 --> 404 Page Not Found: Acl/store
ERROR - 2021-07-05 11:07:20 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 32
ERROR - 2021-07-05 11:07:20 --> Severity: Notice --> Trying to get property 'add' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 21
ERROR - 2021-07-05 11:07:20 --> Severity: Notice --> Trying to get property 'akses' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 27
ERROR - 2021-07-05 11:07:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 32
ERROR - 2021-07-05 11:07:22 --> Severity: Notice --> Trying to get property 'add' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 21
ERROR - 2021-07-05 11:07:22 --> Severity: Notice --> Trying to get property 'akses' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 27
ERROR - 2021-07-05 11:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 32
ERROR - 2021-07-05 11:07:45 --> Severity: Notice --> Trying to get property 'add' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 21
ERROR - 2021-07-05 11:07:45 --> Severity: Notice --> Trying to get property 'akses' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 27
ERROR - 2021-07-05 11:08:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 32
ERROR - 2021-07-05 11:08:35 --> Severity: Notice --> Trying to get property 'add' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 21
ERROR - 2021-07-05 11:08:35 --> Severity: Notice --> Trying to get property 'akses' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 27
ERROR - 2021-07-05 11:08:36 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 32
ERROR - 2021-07-05 11:08:36 --> Severity: Notice --> Trying to get property 'add' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 21
ERROR - 2021-07-05 11:08:36 --> Severity: Notice --> Trying to get property 'akses' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 27
ERROR - 2021-07-05 11:08:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 32
ERROR - 2021-07-05 11:08:37 --> Severity: Notice --> Trying to get property 'add' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 21
ERROR - 2021-07-05 11:08:37 --> Severity: Notice --> Trying to get property 'akses' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 27
ERROR - 2021-07-05 11:08:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 32
ERROR - 2021-07-05 11:08:37 --> Severity: Notice --> Trying to get property 'add' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 21
ERROR - 2021-07-05 11:08:37 --> Severity: Notice --> Trying to get property 'akses' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 27
ERROR - 2021-07-05 11:08:38 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 32
ERROR - 2021-07-05 11:08:38 --> Severity: Notice --> Trying to get property 'add' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 21
ERROR - 2021-07-05 11:08:38 --> Severity: Notice --> Trying to get property 'akses' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 27
ERROR - 2021-07-05 11:08:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 32
ERROR - 2021-07-05 11:08:57 --> Severity: Notice --> Trying to get property 'add' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 21
ERROR - 2021-07-05 11:08:57 --> Severity: Notice --> Trying to get property 'akses' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\index.php 27
ERROR - 2021-07-05 11:09:18 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\AclController.php 46
ERROR - 2021-07-05 11:09:18 --> Severity: Notice --> Trying to get property 'add' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\index.php 22
ERROR - 2021-07-05 11:09:18 --> Severity: Notice --> Trying to get property 'akses' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\acl\index.php 28
