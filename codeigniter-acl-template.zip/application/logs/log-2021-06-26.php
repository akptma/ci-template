<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-26 00:16:56 --> Severity: Notice --> Undefined variable: status D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 99
ERROR - 2021-06-26 00:20:42 --> Severity: Notice --> Undefined variable: status D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 99
ERROR - 2021-06-26 00:21:40 --> Severity: Notice --> Undefined variable: status D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 99
ERROR - 2021-06-26 00:22:32 --> Severity: Notice --> Undefined variable: status D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 99
ERROR - 2021-06-26 00:22:51 --> Severity: Notice --> Undefined variable: status D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 99
ERROR - 2021-06-26 00:23:46 --> Severity: Notice --> Undefined variable: status D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 99
ERROR - 2021-06-26 00:23:57 --> Severity: Notice --> Undefined variable: status D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 99
ERROR - 2021-06-26 10:37:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:37:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:38:03 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:38:03 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:38:23 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:38:23 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:38:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:38:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:41:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:41:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:41:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:41:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:41:40 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:41:40 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:41:51 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:41:51 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:41:56 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:41:56 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:42:04 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:42:04 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:42:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:42:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:42:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:42:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:42:41 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:42:41 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:44:20 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:44:20 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:44:25 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:44:25 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:44:32 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:44:32 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:45:03 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:45:03 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:45:07 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:45:07 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:45:16 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:45:16 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:45:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:45:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:45:59 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:45:59 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:46:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:46:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:46:38 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:46:38 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:46:41 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:46:41 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:46:53 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 10:46:53 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:15:42 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\index.php 41
ERROR - 2021-06-26 11:15:42 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\index.php 41
ERROR - 2021-06-26 11:15:42 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\index.php 41
ERROR - 2021-06-26 11:15:42 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\index.php 41
ERROR - 2021-06-26 11:27:09 --> Query error: Unknown column 'nama' in 'field list' - Invalid query: INSERT INTO `roles` (`nama`) VALUES ('users')
ERROR - 2021-06-26 11:38:43 --> Severity: error --> Exception: Too few arguments to function Roles_model::show(), 1 passed in D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\RolesController.php on line 57 and exactly 2 expected D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Roles_model.php 33
ERROR - 2021-06-26 11:44:13 --> 404 Page Not Found: Role/store
ERROR - 2021-06-26 11:46:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:46:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:47:28 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:47:28 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:47:43 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:47:43 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:47:46 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:47:46 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:48:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:48:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:48:58 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:48:58 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:49:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:49:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:50:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:50:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:50:39 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:50:39 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:50:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:50:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:51:01 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:51:01 --> 404 Page Not Found: Public/template
ERROR - 2021-06-26 11:52:00 --> Severity: Notice --> Trying to get property 'img' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\show.php 16
ERROR - 2021-06-26 11:52:00 --> Severity: Notice --> Trying to get property 'username' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\show.php 25
ERROR - 2021-06-26 11:52:00 --> Severity: Notice --> Trying to get property 'nama_role' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\show.php 31
ERROR - 2021-06-26 11:52:00 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\show.php 39
ERROR - 2021-06-26 11:52:00 --> Severity: Notice --> Trying to get property 'email' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\users\show.php 45
ERROR - 2021-06-26 12:12:39 --> Severity: Notice --> Undefined variable: role D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 16
ERROR - 2021-06-26 12:12:39 --> Severity: Notice --> Trying to get property 'nama_role' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 16
ERROR - 2021-06-26 12:12:39 --> Severity: Notice --> Undefined variable: role D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 22
ERROR - 2021-06-26 12:12:39 --> Severity: Notice --> Trying to get property 'status' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 22
ERROR - 2021-06-26 12:12:39 --> Severity: Notice --> Undefined variable: role D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 30
ERROR - 2021-06-26 12:12:39 --> Severity: Notice --> Trying to get property 'created_at' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 30
ERROR - 2021-06-26 12:12:39 --> Severity: Notice --> Undefined variable: role D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 36
ERROR - 2021-06-26 12:12:39 --> Severity: Notice --> Trying to get property 'updated_at' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 36
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'username' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 54
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 55
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'email' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 56
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'status' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 57
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'status' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 57
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'username' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 54
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 55
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'email' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 56
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'status' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 57
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'status' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 57
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'username' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 54
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 55
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'email' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 56
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'status' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 57
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'status' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 57
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'username' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 54
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'name' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 55
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'email' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 56
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'status' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 57
ERROR - 2021-06-26 12:17:47 --> Severity: Notice --> Trying to get property 'status' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 57
ERROR - 2021-06-26 12:18:23 --> Severity: Notice --> Undefined property: stdClass::$name D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\roles\show.php 55
ERROR - 2021-06-26 15:05:02 --> 404 Page Not Found: Dashboard-ecommercehtml/index
ERROR - 2021-06-26 15:10:44 --> Query error: Unknown column 'a.nama_role' in 'field list' - Invalid query: SELECT `a`.`id`, `a`.`username`, `a`.`nama_role`, `a`.`nama`, `a`.`email`, `a`.`status`
FROM `users` `a`
JOIN `roles` `b` ON `b`.`id` = `a`.`role_id`
