<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-28 09:48:07 --> 404 Page Not Found: SubmenuController/create
ERROR - 2021-06-28 10:12:32 --> 404 Page Not Found: Submenu/create
ERROR - 2021-06-28 10:20:47 --> Severity: error --> Exception: Too few arguments to function SubmenuController::store(), 0 passed in D:\xampp\htdocs\kumpul\codeigniter-acl-template\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\SubmenuController.php 40
ERROR - 2021-06-28 10:21:19 --> Severity: Notice --> Undefined property: SubmenuController::$menu_m D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\SubmenuController.php 50
ERROR - 2021-06-28 10:21:19 --> Severity: error --> Exception: Call to a member function store() on null D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\SubmenuController.php 50
ERROR - 2021-06-28 15:04:55 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\menu\edit.php 18
ERROR - 2021-06-28 15:04:55 --> Severity: Notice --> Trying to get property 'title_menu' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\menu\edit.php 26
ERROR - 2021-06-28 15:04:55 --> Severity: Notice --> Trying to get property 'icons' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\menu\edit.php 33
ERROR - 2021-06-28 15:05:00 --> Severity: Notice --> Trying to get property 'title_menu' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\menu\show.php 16
ERROR - 2021-06-28 15:05:00 --> Severity: Notice --> Trying to get property 'status' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\menu\show.php 22
ERROR - 2021-06-28 15:05:00 --> Severity: Notice --> Trying to get property 'created_at' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\menu\show.php 30
ERROR - 2021-06-28 15:05:00 --> Severity: Notice --> Trying to get property 'updated_at' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\menu\show.php 36
ERROR - 2021-06-28 15:05:55 --> Severity: Notice --> Object of class stdClass could not be converted to int D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Menu_model.php 27
ERROR - 2021-06-28 15:10:54 --> Severity: Notice --> Object of class stdClass could not be converted to int D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Menu_model.php 27
ERROR - 2021-06-28 15:14:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\menu\index.php 33
ERROR - 2021-06-28 15:25:46 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\menu\edit.php 18
ERROR - 2021-06-28 15:25:46 --> Severity: Notice --> Trying to get property 'title_menu' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\menu\edit.php 26
ERROR - 2021-06-28 15:25:46 --> Severity: Notice --> Trying to get property 'icons' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\menu\edit.php 33
ERROR - 2021-06-28 15:27:26 --> Severity: Notice --> Undefined property: stdClass::$route D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\submenu\show.php 22
ERROR - 2021-06-28 15:55:18 --> 404 Page Not Found: Okoc/index
ERROR - 2021-06-28 16:01:06 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:01:06 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:01:13 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:01:13 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:02:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:02:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:02:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:02:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:04:00 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:04:00 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:04:06 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:04:06 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:10:15 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:10:15 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:10:17 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:10:18 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:14:20 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:14:20 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:14:31 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:14:31 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:14:55 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:14:55 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:14:57 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:14:57 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:18:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:18:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:18:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:18:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:19:19 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:19:19 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:19:23 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:19:23 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:19:28 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:19:28 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:20:49 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:20:49 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:20:51 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:20:51 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:21:57 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:21:57 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:21:58 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:21:58 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:22:00 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:22:00 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:24:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:24:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:24:45 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:24:45 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:25:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:25:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:25:53 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:25:53 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:28:10 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:28:10 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:28:13 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:28:13 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:28:49 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:28:49 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:28:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:28:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:30:06 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:30:06 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:30:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:30:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:30:36 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:30:36 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:32:46 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:32:46 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:32:48 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:32:48 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:32:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:32:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:32:57 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:32:57 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:32:59 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:32:59 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:36:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:36:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:36:34 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:36:34 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:36:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:36:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:36:40 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:36:40 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:36:42 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:36:42 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:36:54 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:36:54 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:37:59 --> Severity: error --> Exception: syntax error, unexpected '?>' D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\layouts\backend\footer.php 26
ERROR - 2021-06-28 16:38:27 --> Severity: Notice --> Undefined variable: param D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\layouts\backend\footer.php 26
ERROR - 2021-06-28 16:38:55 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:38:55 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:38:59 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:38:59 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:41:10 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:41:10 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:41:11 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:41:11 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:41:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:41:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:41:57 --> 404 Page Not Found: DevelopController/sidebar_aktif
ERROR - 2021-06-28 16:41:57 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:41:57 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:42:38 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:42:38 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:42:43 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:42:43 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:43:13 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:43:13 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:43:17 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:43:17 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:46:14 --> 404 Page Not Found: User/index
ERROR - 2021-06-28 16:46:17 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:46:17 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:46:19 --> 404 Page Not Found: User/index
ERROR - 2021-06-28 16:46:59 --> Severity: error --> Exception: Too few arguments to function UsersController::index(), 0 passed in D:\xampp\htdocs\kumpul\codeigniter-acl-template\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 25
ERROR - 2021-06-28 16:47:06 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:47:06 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:47:07 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:47:07 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:47:09 --> Severity: error --> Exception: Too few arguments to function UsersController::index(), 0 passed in D:\xampp\htdocs\kumpul\codeigniter-acl-template\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 25
ERROR - 2021-06-28 16:47:31 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:47:31 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:48:03 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:48:03 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:08 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:08 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:15 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:15 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:21 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:21 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:23 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:23 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:24 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:24 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:32 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:32 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:34 --> 404 Page Not Found: User/index
ERROR - 2021-06-28 16:52:36 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:36 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:40 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:40 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:45 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:45 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:49 --> 404 Page Not Found: User/index
ERROR - 2021-06-28 16:52:51 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:52:51 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:55:57 --> 404 Page Not Found: User/2
ERROR - 2021-06-28 16:56:00 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php 28
ERROR - 2021-06-28 16:56:19 --> Severity: error --> Exception: Too few arguments to function CI_URI::segment(), 0 passed in D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\UsersController.php on line 28 and at least 1 expected D:\xampp\htdocs\kumpul\codeigniter-acl-template\system\core\URI.php 344
ERROR - 2021-06-28 16:57:38 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:57:38 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:57:41 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:57:41 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:57:43 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:57:43 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:57:45 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:57:45 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:59:34 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:59:34 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:59:35 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:59:35 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:59:38 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 16:59:38 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 17:05:08 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 17:05:08 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 17:05:10 --> 404 Page Not Found: Public/template
ERROR - 2021-06-28 17:05:10 --> 404 Page Not Found: Public/template
