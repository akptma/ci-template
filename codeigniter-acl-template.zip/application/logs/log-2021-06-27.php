<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-27 16:06:19 --> 404 Page Not Found: Menu/index
ERROR - 2021-06-27 16:13:22 --> 404 Page Not Found: Menu/index
ERROR - 2021-06-27 16:13:42 --> 404 Page Not Found: Menu/index
ERROR - 2021-06-27 16:14:00 --> Query error: Unknown column 'title' in 'field list' - Invalid query: SELECT id,title,status FROM menu WHERE id = kode_menu AND status = 1
ERROR - 2021-06-27 16:16:44 --> 404 Page Not Found: MenuController/create
ERROR - 2021-06-27 16:29:32 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:29:32 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:34:15 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:34:15 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:34:35 --> 404 Page Not Found: Submenu/index
ERROR - 2021-06-27 16:35:03 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:35:03 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:35:05 --> 404 Page Not Found: Submenu/index
ERROR - 2021-06-27 16:35:55 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:35:55 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:35:58 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::order_by() D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Submenu_model.php 20
ERROR - 2021-06-27 16:36:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:36:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:36:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:36:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:36:46 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::order_by() D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Submenu_model.php 20
ERROR - 2021-06-27 16:37:34 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:37:34 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:37:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:37:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:37:48 --> Severity: error --> Exception: Call to a member function order_by() on array D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Submenu_model.php 20
ERROR - 2021-06-27 16:38:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:38:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:38:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:38:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:38:53 --> Severity: Notice --> Undefined property: stdClass::$route D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\submenu\index.php 39
ERROR - 2021-06-27 16:38:53 --> Severity: Notice --> Undefined property: stdClass::$route D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\submenu\index.php 39
ERROR - 2021-06-27 16:38:53 --> Severity: Notice --> Undefined property: stdClass::$route D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\submenu\index.php 39
ERROR - 2021-06-27 16:38:53 --> Severity: Notice --> Undefined property: stdClass::$route D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\submenu\index.php 39
ERROR - 2021-06-27 16:38:53 --> Severity: Notice --> Undefined property: stdClass::$route D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\submenu\index.php 39
ERROR - 2021-06-27 16:43:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:43:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:44:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:44:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:45:11 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:45:11 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:46:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:46:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:49:56 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:49:56 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:51:09 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:51:09 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:52:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:52:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:57:01 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:57:01 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:57:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:57:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:57:54 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:57:54 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:58:04 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:58:04 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:58:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:58:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:59:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 16:59:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:00:08 --> 404 Page Not Found: MenuController/create
ERROR - 2021-06-27 17:00:11 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:00:11 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:00:24 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:00:24 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:00:35 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:00:35 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:00:46 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:00:46 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:00:58 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:00:58 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:06:20 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:06:20 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:06:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:06:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:07:15 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:07:15 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:08:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:08:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:11:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:11:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:11:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 17:11:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 20:57:25 --> 404 Page Not Found: MenuController/edit
ERROR - 2021-06-27 20:59:05 --> 404 Page Not Found: MenuController/edit
ERROR - 2021-06-27 21:26:29 --> Could not find the language line "form_validation_string"
ERROR - 2021-06-27 21:26:43 --> Severity: Notice --> Object of class stdClass could not be converted to int D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Menu_model.php 27
ERROR - 2021-06-27 21:32:14 --> Severity: Notice --> Undefined property: stdClass::$icons D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\menu\edit.php 33
ERROR - 2021-06-27 21:39:42 --> Severity: error --> Exception: Too few arguments to function MenuController::edit(), 0 passed in D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\MenuController.php on line 80 and exactly 1 expected D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\MenuController.php 65
ERROR - 2021-06-27 21:40:24 --> Severity: error --> Exception: Too few arguments to function MenuController::edit(), 0 passed in D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\MenuController.php on line 80 and exactly 1 expected D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\MenuController.php 65
ERROR - 2021-06-27 21:57:14 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 21:57:14 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 21:57:22 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 21:57:22 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 21:57:59 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 21:57:59 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 21:58:32 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 21:58:32 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 21:58:59 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 21:58:59 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 21:59:24 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 21:59:24 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:00:03 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:00:03 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:02:23 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:02:23 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:02:45 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:02:45 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:03:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:03:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:04:18 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:04:18 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:04:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:04:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:06:22 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:06:22 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:06:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:06:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:08:01 --> 404 Page Not Found: Public/template
ERROR - 2021-06-27 22:08:01 --> 404 Page Not Found: Public/template
