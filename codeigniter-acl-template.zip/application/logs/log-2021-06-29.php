<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-29 08:17:31 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:31 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:35 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:35 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:36 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:36 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:38 --> 404 Page Not Found: Okoc/index
ERROR - 2021-06-29 08:17:39 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:39 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:43 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:43 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:45 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:45 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:17:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:45:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:45:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:45:43 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:45:43 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:48:41 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-06-29 08:48:43 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:48:43 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 08:59:59 --> 404 Page Not Found: Okoc/index
ERROR - 2021-06-29 09:00:14 --> Severity: Notice --> Trying to get property 'kode_menu' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\layouts\backend\header.php 379
ERROR - 2021-06-29 09:00:14 --> Severity: Notice --> Trying to get property 'title_menu' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\layouts\backend\header.php 379
ERROR - 2021-06-29 09:00:14 --> Severity: Notice --> Trying to get property 'nama_menu' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\layouts\backend\header.php 382
ERROR - 2021-06-29 09:00:14 --> Severity: Notice --> Trying to get property 'routes' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\layouts\backend\header.php 387
ERROR - 2021-06-29 09:00:14 --> Severity: Notice --> Trying to get property 'nama_menu' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\layouts\backend\header.php 387
ERROR - 2021-06-29 09:21:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:21:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:21:36 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:21:36 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:21:37 --> 404 Page Not Found: MenuController/show
ERROR - 2021-06-29 09:21:37 --> 404 Page Not Found: MenuController/show
ERROR - 2021-06-29 09:21:37 --> 404 Page Not Found: MenuController/show
ERROR - 2021-06-29 09:21:38 --> 404 Page Not Found: MenuController/show
ERROR - 2021-06-29 09:21:38 --> 404 Page Not Found: MenuController/show
ERROR - 2021-06-29 09:21:38 --> 404 Page Not Found: MenuController/show
ERROR - 2021-06-29 09:21:38 --> 404 Page Not Found: MenuController/show
ERROR - 2021-06-29 09:21:38 --> 404 Page Not Found: MenuController/show
ERROR - 2021-06-29 09:21:39 --> 404 Page Not Found: MenuController/show
ERROR - 2021-06-29 09:21:51 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:21:51 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:22:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:22:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:22:22 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:22:22 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:22:58 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:22:58 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:23:11 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:23:11 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:30:57 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:30:57 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:34:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:34:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:34:47 --> Severity: Notice --> Trying to get property 'kode_menu' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\layouts\backend\header.php 389
ERROR - 2021-06-29 09:34:47 --> Severity: Notice --> Trying to get property 'title_menu' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\layouts\backend\header.php 389
ERROR - 2021-06-29 09:34:47 --> Severity: Notice --> Trying to get property 'nama_menu' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\layouts\backend\header.php 392
ERROR - 2021-06-29 09:34:47 --> Severity: Notice --> Trying to get property 'routes' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\layouts\backend\header.php 397
ERROR - 2021-06-29 09:34:47 --> Severity: Notice --> Trying to get property 'nama_menu' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\layouts\backend\header.php 397
ERROR - 2021-06-29 09:34:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:34:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:35:28 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:35:28 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:35:38 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:35:38 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:35:42 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:35:42 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:35:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:35:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:36:34 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:36:34 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:36:36 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:36:36 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:36:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:36:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:36:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:36:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:36:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:36:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:36:51 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:36:51 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:37:45 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:37:45 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:37:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:37:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:47:06 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:47:06 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:47:09 --> 404 Page Not Found: App-config/index
ERROR - 2021-06-29 09:49:25 --> Severity: Notice --> Undefined variable: menu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-app\edit.php 26
ERROR - 2021-06-29 09:49:25 --> Severity: Notice --> Trying to get property 'title_menu' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-app\edit.php 26
ERROR - 2021-06-29 09:49:25 --> Severity: Notice --> Undefined variable: menu D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-app\edit.php 33
ERROR - 2021-06-29 09:49:25 --> Severity: Notice --> Trying to get property 'icons' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\backend\config-app\edit.php 33
ERROR - 2021-06-29 09:49:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:49:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:52:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:52:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:52:59 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:52:59 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:53:09 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:53:09 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:53:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:53:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:57:10 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:57:10 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:58:03 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:58:03 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:59:14 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:59:14 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:59:31 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 09:59:31 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:00:42 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:00:42 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:01:00 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:01:00 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:06:01 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:06:01 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:06:02 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:06:02 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:06:04 --> Severity: Notice --> Trying to get property 'nav_logo' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\ConfigController.php 35
ERROR - 2021-06-29 10:06:20 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:06:20 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:06:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:06:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:21:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:21:53 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:21:54 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:21:54 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:42:25 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:42:25 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:43:25 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:43:25 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:43:26 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 25
ERROR - 2021-06-29 10:43:28 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:43:28 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:44:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:44:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:44:34 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 25
ERROR - 2021-06-29 10:44:35 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:44:35 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:46:02 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:46:02 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:46:15 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:46:15 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:46:27 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 25
ERROR - 2021-06-29 10:46:55 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:46:55 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:46:57 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:46:57 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:47:12 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:47:12 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:47:49 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:47:49 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:48:12 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:48:12 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:48:48 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:48:48 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:49:04 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:49:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:49:23 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:49:23 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:49:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:49:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:49:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:49:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:49:29 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:49:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:50:55 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:50:55 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:50:57 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:50:57 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:51:32 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:51:32 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:51:36 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:51:36 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:51:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:51:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:51:53 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:51:53 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:52:56 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:52:56 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:55:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:55:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:57:17 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:57:17 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:57:19 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:57:19 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:59:29 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:59:29 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:59:29 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:59:29 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:59:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:59:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:59:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:59:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:59:34 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\ConfigController.php 40
ERROR - 2021-06-29 10:59:34 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 26
ERROR - 2021-06-29 10:59:35 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 10:59:35 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:00:21 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:00:21 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:00:25 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\ConfigController.php 40
ERROR - 2021-06-29 11:00:25 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 26
ERROR - 2021-06-29 11:00:25 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:00:25 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:00:43 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:00:43 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:00:46 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\ConfigController.php 40
ERROR - 2021-06-29 11:00:46 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 26
ERROR - 2021-06-29 11:00:46 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:00:46 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:01:10 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:01:10 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:01:13 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\ConfigController.php 40
ERROR - 2021-06-29 11:01:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:01:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:01:53 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:01:53 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:01:53 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:01:53 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:01:55 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\ConfigController.php 40
ERROR - 2021-06-29 11:02:34 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:02:34 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:02:35 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:02:35 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:06 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:06 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:09 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:09 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:10 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:10 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:19 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:19 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:19 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:19 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:46 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:46 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:56 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:56 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:57 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:03:57 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:04:17 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:04:17 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:04:18 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:04:18 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:06:49 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:06:49 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:06:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:06:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:06:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:06:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:06:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:06:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:06:59 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:07:00 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:07:08 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:07:08 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:07:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:07:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:07:28 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:07:28 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:08:10 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:08:10 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:08:13 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:08:13 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:09:21 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:09:21 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:09:22 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:09:22 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:11:32 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:11:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:11:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:11:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:11:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:11:33 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:13:09 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:13:10 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:13:11 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:13:11 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:13:46 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:13:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:14:20 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:14:20 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:14:25 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:14:25 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:14:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:14:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:15:04 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:15:04 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:15:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:15:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:19:21 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:19:21 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:19:22 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:19:22 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:19:25 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\ConfigController.php 40
ERROR - 2021-06-29 11:19:25 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 26
ERROR - 2021-06-29 11:19:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:19:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:19:39 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\ConfigController.php 40
ERROR - 2021-06-29 11:19:39 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 26
ERROR - 2021-06-29 11:19:40 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:19:40 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:20:01 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\ConfigController.php 40
ERROR - 2021-06-29 11:20:01 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 26
ERROR - 2021-06-29 11:20:01 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:20:01 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:20:35 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:20:35 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:20:37 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\ConfigController.php 40
ERROR - 2021-06-29 11:21:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:21:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:21:45 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:21:45 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:27:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:27:30 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:27:31 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:27:31 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:27:34 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:27:34 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:27:38 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:27:38 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:30:25 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:30:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:30:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:30:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:32:10 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:32:10 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:33:11 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:33:11 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:33:15 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:33:15 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:33:15 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:33:15 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:33:43 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:33:43 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:33:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:33:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:33:49 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:33:49 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:33:54 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:33:54 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:34:59 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:34:59 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:35:00 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:35:00 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:35:23 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:35:23 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:35:24 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:35:24 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:35:34 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 26
ERROR - 2021-06-29 11:35:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:35:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:35:38 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:35:38 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:35:41 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 26
ERROR - 2021-06-29 11:35:55 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:35:56 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:35:59 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 26
ERROR - 2021-06-29 11:36:04 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:36:04 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:36:08 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:36:08 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:37:06 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:37:06 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:37:07 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:37:07 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:37:10 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 26
ERROR - 2021-06-29 11:37:15 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:37:15 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:37:18 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 26
ERROR - 2021-06-29 11:37:20 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:37:20 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:37:56 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:37:56 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:38:01 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\ConfigController.php 46
ERROR - 2021-06-29 11:38:04 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:38:04 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:38:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:38:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:38:08 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\ConfigController.php 46
ERROR - 2021-06-29 11:38:13 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:38:13 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:38:16 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\ConfigController.php 46
ERROR - 2021-06-29 11:39:25 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:39:25 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:39:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:39:26 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:39:29 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\controllers\ConfigController.php 46
ERROR - 2021-06-29 11:40:51 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:40:51 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:40:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:40:52 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:40:57 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 26
ERROR - 2021-06-29 11:41:00 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:41:00 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:41:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:41:27 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:41:34 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:41:34 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:43:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:43:05 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:43:41 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:43:41 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:43:48 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:43:48 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:44:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:44:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:44:44 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 26
ERROR - 2021-06-29 11:44:49 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:44:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:44:52 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 26
ERROR - 2021-06-29 11:45:01 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:45:01 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:45:17 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:45:17 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:45:46 --> Severity: Notice --> Undefined index: nav_logo D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\models\Config_model.php 26
ERROR - 2021-06-29 11:45:46 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:45:46 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:50:00 --> Severity: Notice --> Undefined variable: nav D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\layouts\backend\footer.php 8
ERROR - 2021-06-29 11:50:00 --> Severity: Notice --> Trying to get property 'foo_brand' of non-object D:\xampp\htdocs\kumpul\codeigniter-acl-template\application\views\layouts\backend\footer.php 8
ERROR - 2021-06-29 11:50:01 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:50:01 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:50:42 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:50:42 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:51:02 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:51:02 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:52:24 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:52:24 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:52:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:52:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:53:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 11:53:50 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:49:39 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:49:39 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:49:45 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:49:45 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:49:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:49:47 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:49:54 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:49:54 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:50:03 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:50:03 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:50:29 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:50:29 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:50:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:50:37 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:50:41 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:50:41 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:50:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:50:44 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:50:48 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 14:50:48 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 15:12:09 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 15:12:09 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 15:12:19 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 15:12:19 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 15:12:29 --> 404 Page Not Found: Public/template
ERROR - 2021-06-29 15:12:29 --> 404 Page Not Found: Public/template
