<?php
defined('BASEPATH') or exit('No direct script access allowed');


class MenuConfController extends CI_Controller
{

  public function __construct()
  {
    parent::__construct();
    forbidden();
    $this->load->model('Menu_model');
    $this->load->model('MenuConf_model', 'menu_m');
  }

  private function _header()
  {
    $this->load->view('layouts/backend/header');
  }
  private function _footer()
  {
    $this->load->view('layouts/backend/footer');
  }

  public function index()
  {
    $this->_header();
    $data = [
      'title' => 'Menu-Config',
      'acl'   => user_control()['acl'][0],
      'menu'  => $this->Menu_model->index(),
    ];
    $this->load->view('backend/config-menu/index', $data);
    $this->_footer();
  }

  public function show($id_menu)
  {
    $data = [
      'submenu' => $this->Menu_model->show($id_menu)['body'],
    ];
    $this->load->view('backend/config-menu/show', $data);
  }

  public function update()
  {
    $post = $this->input->post();
    dump_exit($post);
  }
}


/* End of file MenuConfController.php */
/* Location: ./application/controllers/MenuConfController.php */