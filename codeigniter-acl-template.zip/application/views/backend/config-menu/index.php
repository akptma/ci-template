<section id="ordering">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                </div>
                <div class="card-content collapse show">
                    <div class="card-body card-dashboard">
                        <center>
                            <h1> FITUR INI DALAM PENGEMBANGAN</h1>
                        </center>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>