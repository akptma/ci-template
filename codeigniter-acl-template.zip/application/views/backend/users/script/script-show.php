<script>
    $(document).ready(() => {
        $('#detail_modal').modal('show');
    })
</script>