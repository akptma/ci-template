#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_role` varchar(150) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `roles` (`id`, `nama_role`, `status`, `created_at`) VALUES (1, 'super admin', 1, '2021-06-21 14:22:41');
INSERT INTO `roles` (`id`, `nama_role`, `status`, `created_at`) VALUES (2, 'admin', 1, '2021-06-25 15:53:35');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `nama` varchar(150) DEFAULT NULL,
  `email` varchar(255) NOT NULL DEFAULT '',
  `status` int(11) NOT NULL DEFAULT 1,
  `password` varchar(255) NOT NULL,
  `password_reset` varchar(255) DEFAULT NULL,
  `img` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`,`username`,`email`,`password`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` (`id`, `role_id`, `username`, `nama`, `email`, `status`, `password`, `password_reset`, `img`, `created_at`, `updated_at`, `deleted_at`) VALUES (1, 1, 'admin621', 'B2i', 'admin@admin.com', 1, 'd06ddb23e014f241e464c794f60023dfe5eb5418ec92d2aa66c3335229e9547ca20d4028dcdbb8c13d3fd147ee4c8b6eb9037256a677c92c935ab4cb9dbaf0c1XHBZS+kjkJ1AcQiGHsFLhTRA+Qug9DGqIH6zBDGrbww=', NULL, 'default.png', '2021-06-26 00:22:24', NULL, '2021-06-26 00:26:27');


